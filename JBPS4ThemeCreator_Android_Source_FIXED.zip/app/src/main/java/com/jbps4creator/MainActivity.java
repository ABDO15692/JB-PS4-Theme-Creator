package com.jbps4creator;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;
import org.json.JSONException;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 41;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.addJavascriptInterface(new AndroidFiles(), "AndroidFiles");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (Exception e) { filePathCallback = null; Toast.makeText(MainActivity.this, "Unable to open file picker", Toast.LENGTH_SHORT).show(); return false; }
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    private Uri createDownload(String name, String mime) throws IOException {
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        if (Build.VERSION.SDK_INT >= 29) values.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/JBPS4ThemeCreator");
        Uri collection = Build.VERSION.SDK_INT >= 29 ? MediaStore.Downloads.EXTERNAL_CONTENT_URI : MediaStore.Files.getContentUri("external");
        Uri uri = getContentResolver().insert(collection, values);
        if (uri == null) throw new IOException("Could not create download file");
        return uri;
    }

    private void writeDownload(String name, String mime, byte[] bytes) throws IOException {
        Uri uri = createDownload(name, mime);
        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
            if (out == null) throw new IOException("Could not open output file");
            out.write(bytes);
        }
    }

    public class AndroidFiles {
        @JavascriptInterface public String saveBase64File(String name, String mime, String encoded) {
            try {
                byte[] data = android.util.Base64.decode(encoded, android.util.Base64.DEFAULT);
                writeDownload(name, mime, data);
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Saved to Downloads/JBPS4ThemeCreator", Toast.LENGTH_LONG).show());
                return "OK";
            } catch (Exception e) { return "ERROR: " + e.getMessage(); }
        }

        @JavascriptInterface public String exportThemeSource(String projectJson) {
            try {
                JSONObject project = new JSONObject(projectJson);
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                try (ZipOutputStream zip = new ZipOutputStream(bytes)) {
                    addText(zip, "README.txt", "JB PS4 Theme Creator — source assets\n\nThis is a theme-source bundle, NOT an installable PS4 PKG. A valid PS4 theme package needs PS4-specific metadata and a compatible package builder.\n\nTarget firmware entered by user: 9.00\n");
                    String themeName = project.optString("themeName", "Custom Theme");
                    String author = project.optString("author", "Theme Creator");
                    String accent = project.optString("accent", "#36a9ff");
                    String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<theme>\n  <format-version>1</format-version>\n  <themecolor>" + xmlEscape(accent) + "</themecolor>\n</theme>\n";
                    addText(zip, "theme.xml", xml);
                    JSONObject assets = project.optJSONObject("assets");
                    if (assets != null) {
                        JSONObject wall = assets.optJSONObject("wallpaper");
                        if (wall != null) addImageAsset(zip, wall, "texture/background/homescreen.png", true);
                        String[] keys = {"community","event","friend","message","notification","party","power","setting","trophy"};
                        for (String key : keys) {
                            JSONObject item = assets.optJSONObject(key);
                            if (item != null) addImageAsset(zip, item, "custom_icons/" + key + ".png", false);
                        }
                    }
                    addText(zip, "BUILD_STATUS.txt", "NOT A PKG: this export contains editable source assets only. It does not include param.sfo, Sony publishing binaries, or a verified PS4 package.\nTheme name: " + themeName + "\nAuthor: " + author + "\nAccent: " + accent + "\n");
                }
                writeDownload("jb_ps4_theme_source.zip", "application/zip", bytes.toByteArray());
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Theme source ZIP saved to Downloads", Toast.LENGTH_LONG).show());
                return "OK";
            } catch (Exception e) { return "ERROR: " + e.getMessage(); }
        }

        private void addText(ZipOutputStream zip, String path, String text) throws IOException {
            zip.putNextEntry(new ZipEntry(path)); zip.write(text.getBytes(StandardCharsets.UTF_8)); zip.closeEntry();
        }
        private String xmlEscape(String s) { return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;"); }
        private void addImageAsset(ZipOutputStream zip, JSONObject asset, String path, boolean wallpaper) throws IOException, JSONException {
            String data = asset.optString("data", "");
            int comma = data.indexOf(',');
            if (comma < 0) return;
            byte[] raw = android.util.Base64.decode(data.substring(comma + 1), android.util.Base64.DEFAULT);
            if (wallpaper) {
                Bitmap src = BitmapFactory.decodeByteArray(raw, 0, raw.length);
                if (src != null) {
                    Bitmap outBmp = Bitmap.createBitmap(1920, 1080, Bitmap.Config.ARGB_8888);
                    Canvas canvas = new Canvas(outBmp);
                    Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
                    canvas.drawBitmap(src, null, new Rect(0, 0, 1920, 1080), paint);
                    ByteArrayOutputStream png = new ByteArrayOutputStream();
                    outBmp.compress(Bitmap.CompressFormat.PNG, 100, png);
                    raw = png.toByteArray(); src.recycle(); outBmp.recycle();
                }
            }
            zip.putNextEntry(new ZipEntry(path)); zip.write(raw); zip.closeEntry();
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
